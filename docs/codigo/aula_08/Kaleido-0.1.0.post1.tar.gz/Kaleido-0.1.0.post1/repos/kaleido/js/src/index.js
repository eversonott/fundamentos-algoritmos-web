module.exports = {
    name: 'kaleido_scopes',
    plotly: require('./plotly/render'),
    // Additional plugins go here
}
