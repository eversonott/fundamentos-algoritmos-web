from os.path import dirname, abspath, join
import pathlib
tests_root = pathlib.Path(__file__).parent
baseline_root = tests_root / 'baselines'
